﻿using DoctorAppointmentSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using System.Windows.Forms;

namespace DoctorAppointmentSystem.Controllers
{
    public class ReceptionController : Controller
    {
        dbDoctorAppointmentEntities db = new dbDoctorAppointmentEntities();
        dbDoctorAppointmentEntities1 db1 = new dbDoctorAppointmentEntities1();
        dbDoctorAppointmentEntities5 db2 = new dbDoctorAppointmentEntities5();
        [HttpGet]
        public ActionResult ReceptionRegister()
        {
            return View();
        }

        [HttpPost]
        public ActionResult ReceptionRegister(tblPatientOfficial1 patientDetail)
        {
            string MESSAGE = string.Empty;
            if (ModelState.IsValid)
            {
                db1.sp_ReceptionistPatient1(patientDetail.iPatientId, patientDetail.cFirstName, patientDetail.cLastName, patientDetail.cDepartment, patientDetail.cDoctorName, patientDetail.cAge, patientDetail.cAddress, patientDetail.cMobileNumber, patientDetail.dAppointmentDate, patientDetail.cAppointmentTime,patientDetail.cPatientType);
                //db.tblPatientDetails.Add(tblPatientDetail);
                db1.SaveChanges();
                ViewBag.message = "Registration Successfull";
                MESSAGE = "Registration Successfull";
                System.Windows.Forms.MessageBox.Show(MESSAGE);
                return RedirectToAction("ReceptionistHome", "Reception");
            }

            return View(patientDetail);
        }

        public ActionResult ReceptionistHome()
        {
            if (Session["UserId"] != null)
            {
                return View();
            }
            else
            {
                return RedirectToAction("UserLogin","Login");
            }
        }

        public ActionResult DepartmentDoctor()
        {
            return View(db.tblDepartmentDoctors.ToList());
        }

        public ActionResult Patients()
        {
            return View(db1.tblPatientOfficial1.ToList());
        }

        //public ActionResult GenerateBill()
        //{
        //    var model = (from u in db1.tblPatientOfficial1
        //                 select u);

        //    return View(model);
        //}


        //public ActionResult EditBill(int? id)
        //{
        //    var model = (from u in db1.tblPatientOfficial1
        //                 where u.iPatientId.Equals((int)id)
        //                 select u).FirstOrDefault();

        //    return View(model);
        //}

        //[HttpPost]
        //public ActionResult EditBill(tblPatientOfficial1 patient)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        db.sp_Dues(patient.iPatientId, patient.cDues);
        //        db.SaveChanges();
        //        MessageBox.Show("Bill added successfully.....!!!");
        //        return RedirectToAction("ReceptionistHome", "Reception");
        //    }
        //    return View();
        //}

        //public ActionResult ViewBills()
        //{
        //    var m = (from u in db1.tblPatientOfficial1
        //             where u.cDues != "No Dues"
        //             select u);

        //    return View(m);
        //}

        public ActionResult Bed_Availability()
        {
            var model = (from u in db2.tblBedAvailabilities

                         select u).ToList();
            return View(model);
        }

        public ActionResult EditBed(string Availability)
        {
            if (Availability == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tblBedAvailability deptinfo = db2.tblBedAvailabilities.Where(d => d.Availability == Availability).FirstOrDefault();
            if (deptinfo == null)
            {
                return HttpNotFound();
            }
           
            return View(deptinfo);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult EditBed(/*[Bind(Include = "cDoctorName,cDepartment")]*/ tblBedAvailability deptinfo)
        {
            if (ModelState.IsValid)
            {
                //db.Entry(deptinfo).State = EntityState.Modified;
                var doc = db2.tblBedAvailabilities.Where(x => x.WardNo == deptinfo.WardNo).FirstOrDefault();
                doc.Availability = deptinfo.Availability;
                doc.BedNo = deptinfo.BedNo;
                db.SaveChanges();
                return RedirectToAction("Bed_Availability");
            }
            ViewBag.vUserId = new SelectList(db2.tblBedAvailabilities, "BedNo", "Availability");
            return View(deptinfo);
        }



        //public ActionResult EditBed1(string Availability)
        //{
        //    if (Availability == null)
        //    {
        //        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        //    }
        //    tblBedAvailability deptinfo = db2.tblBedAvailabilities.Where(d => d.Availability == Availability).FirstOrDefault();
        //    if (deptinfo == null)
        //    {
        //        return HttpNotFound();
        //    }
        //    // ViewBag.vUserId = new SelectList(db.tblDepartmentDoctors, "vUserId", "vFullname");
        //    return View(deptinfo);
        //}
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public ActionResult EditBed1(/*[Bind(Include = "cDoctorName,cDepartment")]*/ tblBedAvailability deptinfo)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        //db.Entry(deptinfo).State = EntityState.Modified;
        //        var doc = db2.tblBedAvailabilities.Where(x => x.WardNo == deptinfo.WardNo).FirstOrDefault();
        //        doc.Availability = deptinfo.Availability;
        //         doc.BedNo = deptinfo.BedNo;
        //        db.SaveChanges();
        //        return RedirectToAction("Bed_Availability");
        //    }
        //    ViewBag.vUserId = new SelectList(db2.tblBedAvailabilities, "WardNo", "BedNo", "Availability");
        //    return View(deptinfo);
        //}



        public ActionResult LogOut()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Index", "Home");
        }
    }
}