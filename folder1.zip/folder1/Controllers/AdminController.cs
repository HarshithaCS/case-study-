﻿using DoctorAppointmentSystem.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using System.Windows.Forms;

namespace DoctorAppointmentSystem.Controllers
{
    public class AdminController : Controller
    {
        dbDoctorAppointmentEntities db = new dbDoctorAppointmentEntities();
        dbDoctorAppointmentEntities1 db1 = new dbDoctorAppointmentEntities1();
        dbDoctorAppointmentEntities5 db2 = new dbDoctorAppointmentEntities5();
        public ActionResult AdminHome()
        {
            return View();
        }

        public ActionResult Bed_Availability()
        {
            var model = (from u in db2.tblBedAvailabilities

                         select u).ToList();
            return View(model);
        }


        public ActionResult PatientDetails()
        {
            var model = (from u in db1.tblPatientOfficial1
                         select u).ToList();

            return View(model);
        }

        public ActionResult DepartmentDoctor()
        {
            var model = (from u in db.tblDepartmentDoctors
                         select u).ToList();

            return View(model);
        }

        public ActionResult LogOut()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Index", "Home");
        }
        // GET: tblCarRegistrationDetails/Edit/5
        public ActionResult EditDoctor(string cDoctorName)
        {
            if (cDoctorName == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tblDepartmentDoctor deptinfo = db.tblDepartmentDoctors.Where(d => d.cDoctorName == cDoctorName).FirstOrDefault();
            if (deptinfo == null)
            {
                return HttpNotFound();
            }
            // ViewBag.vUserId = new SelectList(db.tblDepartmentDoctors, "vUserId", "vFullname");
            return View(deptinfo);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult EditDoctor(/*[Bind(Include = "cDoctorName,cDepartment")]*/ tblDepartmentDoctor deptinfo)
        {
            if (ModelState.IsValid)
            {
                //db.Entry(deptinfo).State = EntityState.Modified;
                var doc = db.tblDepartmentDoctors.Where(x => x.iDeptId == deptinfo.iDeptId).FirstOrDefault();
                doc.cDoctorName = deptinfo.cDoctorName;
                doc.cDepartment = deptinfo.cDepartment;
                db.SaveChanges();
                return RedirectToAction("DepartmentDoctor");
            }
            ViewBag.vUserId = new SelectList(db.tblDepartmentDoctors, "cDoctorName", "cDepartment");
            return View(deptinfo);
        }




        












    }

        //public ActionResult DoctorLeave()
        //{
        //    var model = (from u in db.tblDepartmentDoctors
        //                 where u.cLeaveStatus.Equals("On Leave")
        //                 select u).ToList();

        //    return View(model);
    }
    