﻿using DoctorAppointmentSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using System.Windows.Forms;

namespace DoctorAppointmentSystem.Controllers
{
    public class LoginController : Controller
    {
        dbDoctorAppointmentEntities1 db1 = new dbDoctorAppointmentEntities1();
        dbDoctorAppointmentEntities db = new dbDoctorAppointmentEntities();

        [HttpGet]
        public ActionResult ReceptionRegister()
        {
            return View();
        }

        [HttpPost]
        public ActionResult ReceptionRegister(tblPatientOfficial1 patientDetail)
        {
            string MESSAGE = string.Empty;
            if (ModelState.IsValid)
            {
                db1.sp_ReceptionistPatient1(patientDetail.iPatientId,patientDetail.cFirstName, patientDetail.cLastName, patientDetail.cDepartment, patientDetail.cDoctorName, patientDetail.cAge, patientDetail.cAddress, patientDetail.cMobileNumber, patientDetail.dAppointmentDate, patientDetail.cAppointmentTime, patientDetail.cPatientType);
              
                db1.SaveChanges();
                ViewBag.message = "Registration Successfull";
                MESSAGE = "Registration Successfull";
                System.Windows.Forms.MessageBox.Show(MESSAGE);
                return RedirectToAction("UserHome", "Login");
            }

            return View(patientDetail);
        }
        [HttpGet]
        public ActionResult ViewBookedData()
        {
            int id = (int)Session["UserID"];
            var model = (from u in db1.tblPatientOfficial1
                         where u.iPatientId.Equals((int)id)
                         select u).FirstOrDefault();

            return View(model);
        }
        [HttpGet]
        public ActionResult UserLogin()
        {
            return View();
        }

        [HttpPost]
        public ActionResult UserLogin(LoginCredentials UserAuthenticate)
        {
            if (ModelState.IsValid)
            {
                if (UserAuthenticate.UserType == "User Login")
                {
                    var obj = db.tblPatientDetails.Where(a => a.cFirstName.Equals(UserAuthenticate.cUserName) && a.cPassword.Equals(UserAuthenticate.cPassword)).FirstOrDefault();
                    if (obj != null)
                    {
                        Session["UserID"] = obj.iPatientId;
                        Session["UserName"] = obj.cFirstName.ToString();
                      
                        return RedirectToAction("UserHome");
                    }
                    else
                    {
                        MessageBox.Show("Login Credentials are incorrect please try again");
                    }
                }
                else if (UserAuthenticate.UserType == "Receptionist Login")
                {
                    var obj = db.tblLoginHospitals.Where(a => a.cUserName.Equals(UserAuthenticate.cUserName) && a.cPassword.Equals(UserAuthenticate.cPassword)).FirstOrDefault();
                    if (obj != null)
                    {
                        Session["UserId"] = obj.iReceptionistId;
                        Session["UserName"] = obj.cUserName.ToString();
                        Session["Name"] = obj.cRecptionistName;
                        return RedirectToAction("ReceptionistHome", "Reception");
                    }
                    else
                    {
                        MessageBox.Show("Login Credentials are incorrect please try again");
                    }
                }
                else if (UserAuthenticate.UserType == "Doctor Login")
                {
                    var obj = db.tblDepartmentDoctors.Where(a => a.cUserName.Equals(UserAuthenticate.cUserName) && a.cPassword.Equals(UserAuthenticate.cPassword)).FirstOrDefault();
                    if (obj != null)
                    {
                        Session["UserId"] = obj.cUserName;
                        Session["UserName"] = obj.cDoctorName.ToString();
                        return RedirectToAction("DoctorHome", "Doctor");
                    }
                    else
                    {
                        MessageBox.Show("Login Credentials are incorrect please try again");
                    }
                }
                else if (UserAuthenticate.UserType == "Admin Login")
                {
                    var obj = db.tblAdminLogins.Where(a => a.cUserName.Equals(UserAuthenticate.cUserName) && a.cPassword.Equals(UserAuthenticate.cPassword)).FirstOrDefault();
                    if (obj != null)
                    {
                        Session["UserId"] = "Admin Login";
                        Session["UserName"] = "Administrator";
                        return RedirectToAction("AdminHome", "Admin");
                    }
                    else
                    {
                        MessageBox.Show("Login Credentials are incorrect please try again");
                    }
                }
            }
            return View(UserAuthenticate);
        }
        public ActionResult UserHome()
        {
            if (Session["UserID"] != null)
            {
                return View();
            }
            else
            {
                return RedirectToAction("UserLogin");
            }
        }

        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tblPatientDetail patientDetail = db.tblPatientDetails.Single(pat => pat.iPatientId == (int)id);
            if (patientDetail == null)
            {
                return HttpNotFound();
            }
            return View(patientDetail);
        }


        public ActionResult LogOut()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Index", "Home");
        }

      

        public ActionResult ForgotPassword()
        {
            return View();
        }

        [HttpPost]
        public ActionResult ForgotPassword(ForgotPassword forgotPassword)
        {
            



            if (ModelState.IsValid)
            {
                var model = (from u in db.tblLoginHospitals
                             where u.cUserName.Equals(forgotPassword.UserName)
                             select u).FirstOrDefault();
                if (model.cUserName == forgotPassword.UserName)
                {
                    Session["ForgotPassword"] = model.cUserName;
                    Session["UserId"] = model.iReceptionistId;
                    return RedirectToAction("ForgotPassword2", "Login");
                }
                else
                {
                    MessageBox.Show("Invalid User ");
                    return RedirectToAction("UserLogin", "Login");
                }
            }


            return RedirectToAction("UserLogin","Login");
        }

        public ActionResult ForgotPassword2()
        {
            return View();
        }

        [HttpPost]
        public ActionResult ForgotPassword2(Class1 forgotPassword)
        {
            var x = Session["UserId"];

            var model = (from u in db.tblLoginHospitals
                             where u.iReceptionistId.Equals((int)x)
                             select u).FirstOrDefault();
            model.cPassword = forgotPassword.NewPassword;
            db.SaveChanges();
            MessageBox.Show("Password Reset Successfully");
            return RedirectToAction("UserLogin", "Login"); 
        }
    }
}