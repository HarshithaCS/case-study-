﻿using DoctorAppointmentSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Windows.Forms;

namespace DoctorAppointmentSystem.Controllers
{
    public class RegistrationController : Controller
    {
        dbDoctorAppointmentEntities db = new dbDoctorAppointmentEntities(); 
        [HttpGet]
        public ActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Register(tblPatientDetail UserDetail)
        {
            if (ModelState.IsValid)
            {
                db.sp_PatientDetailsRegister(UserDetail.cFirstName, UserDetail.cLastName, UserDetail.cEmailId, UserDetail.cPassword, UserDetail.cSEcurityQuestion, UserDetail.cSecurityAnswer, UserDetail.cAge, UserDetail.cAddress, UserDetail.cMobileNumber);
                //db.tblPatientDetails.Add(tblPatientDetail);
                db.SaveChanges();                
                var message = "Registration Successfull,click ok to login";
                MessageBox.Show(message);
                return RedirectToAction("UserLogin", "Login");
            }
            
            return View(UserDetail);
        }
    }
}