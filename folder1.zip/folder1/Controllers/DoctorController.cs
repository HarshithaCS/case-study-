﻿using DoctorAppointmentSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using System.Windows.Forms;

namespace DoctorAppointmentSystem.Controllers
{
    public class DoctorController : Controller
    {
        dbDoctorAppointmentEntities db = new dbDoctorAppointmentEntities();

        public ActionResult DoctorHome()
        {
            return View();
        }

        public ActionResult LogOut()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Index", "Home");
        }

        public ActionResult Appointment()
        {
           string nameDoctor = (string)Session["UserName"];

            var model = (from u in db.tblPatientOfficials
                         where u.cDoctorName.Equals(nameDoctor)
                         select u).FirstOrDefault();

            return View(model);
        }

        public ActionResult ViewLeave()
        {
            string nameDoctor = (string)Session["UserName"];

            var model = (from u in db.tblDepartmentDoctors
                         where u.cDoctorName.Equals(nameDoctor)
                         select u).FirstOrDefault();

            return View(model);
        }

        public ActionResult ApplyLeave()
        {
            string nameDoctor = (string)Session["UserName"];

            var model = (from u in db.tblDepartmentDoctors
                         where u.cDoctorName.Equals(nameDoctor)
                         select u).FirstOrDefault();

            return View(model);
        }

        [HttpPost]
        public ActionResult ApplyLeave(tblDepartmentDoctor depDoctor)
        {
            if (ModelState.IsValid)
            {               
            string nameDoctor = (string)Session["UserName"];
            db.sp_DoctorLeave(nameDoctor, depDoctor.dLeaveDate);
            db.SaveChanges();
            }

            return View();
        }

        public ActionResult CancelLeave()
        {
            string nameDoctor = (string)Session["UserName"];

            var model = (from u in db.tblDepartmentDoctors
                         where u.cDoctorName.Equals(nameDoctor)
                         select u).FirstOrDefault();

            return View(model);
        }

        [HttpPost]
        public ActionResult CancelLeave(tblDepartmentDoctor depDoctor)
        {
            if (ModelState.IsValid)
            {
                string date = depDoctor.dLeaveDate.ToString();
                string nameDoctor = (string)Session["UserName"];
                var model=(from u in db.tblDepartmentDoctors
                           where u.cDoctorName.Equals(nameDoctor)
                           select u).FirstOrDefault();
                model.cLeaveStatus="available";
                model.dLeaveDate=null;
                db.SaveChanges();
                MessageBox.Show("Leave Cancelled Successfully.....!!!!!");
            }

            return RedirectToAction("DoctorHome");
        }
    }
}