﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace DoctorAppointmentSystem.Models
{
    public class LoginCredentials
    {
        [Required(ErrorMessage="please enter username")]
        public string cUserName { get; set; }
        [DataType(DataType.Password)]
        [Required(ErrorMessage = "please enter password")]
        public string cPassword { get; set; }
        [NotMapped]
        [DataType(DataType.Password)]
        [Required(ErrorMessage="Please enter user type")]
        public string UserType { get; set; }
    }
}