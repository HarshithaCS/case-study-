﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;


namespace casestudyv1
{
    public partial class WebForm19 : System.Web.UI.Page
    {
        SqlConnection sqlConn;
        SqlDataAdapter da;
        DataSet ds;
        protected void Page_Load(object sender, EventArgs e)
        {
            sqlConn = new System.Data.SqlClient.SqlConnection(ConfigurationManager.ConnectionStrings["OHDConn"].ConnectionString);
            sqlConn.Open();
            string queryRequest = "select requestID,userID,request,solution from request where requestID  in( select requestId from processedRequest)";
            da = new SqlDataAdapter(queryRequest, sqlConn);
            ds = new DataSet();
            da.Fill(ds);
            gvRequest.DataSource = ds;
            gvRequest.DataBind();
            sqlConn.Close();

        }

        protected void gvRequest_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}